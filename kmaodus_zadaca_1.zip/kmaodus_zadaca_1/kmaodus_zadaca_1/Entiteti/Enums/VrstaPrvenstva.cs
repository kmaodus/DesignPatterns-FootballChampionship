﻿namespace kmaodus_zadaca_1.Entiteti.Enums
{
    public enum VrstaPrvenstva
    {
        DvoKruzno,
        CetveroKruzno
    }
}
