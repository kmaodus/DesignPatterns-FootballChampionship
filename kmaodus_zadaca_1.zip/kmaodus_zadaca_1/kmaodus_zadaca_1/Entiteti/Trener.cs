﻿namespace kmaodus_zadaca_1.Entiteti
{
    public class Trener : Osoba
    {

    }
}
